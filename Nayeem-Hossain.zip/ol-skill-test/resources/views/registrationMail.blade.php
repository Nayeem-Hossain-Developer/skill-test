<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<h3>Dear {{$user->name}}, Thank you for your registration. Your registered email address is ‘{{$user->email}}’ and phone number ‘{{$user->phone}}’.</h3>
</body>
</html>