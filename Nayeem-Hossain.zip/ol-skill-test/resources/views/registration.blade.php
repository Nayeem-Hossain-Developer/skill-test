<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Registration Form</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-6 mx-auto mt-4">
				<div class="card">
					<div class="card-header text-center bg-info">
						<h5 class="text-white">Registration Form</h5>
					</div>
					<div class="card-body">
						<form action="{{route('registration')}}" method="post">
							@csrf
							<div class="form-group">
								<label for="InputName">Name</label>
								<input type="text" class="form-control @error('name')is-invalid @enderror" id="InputName" name="name" placeholder="Enter your name.." value="{{old('name')}}">
								@error('name')
								<div class="invalid-feedback">
									{{$message}}.
								</div>
								@enderror
							</div>
							<div class="form-group">
								<label for="InputEmail">Email </label>
								<input type="email" class="form-control @error('email')is-invalid @enderror" id="InputEmail" name="email" placeholder="Enter your email.." value="{{old('email')}}" >
								@error('email')
								<div class="invalid-feedback">
									{{$message}}.
								</div>
								@enderror
							</div>
							<div class="form-group">
								<label for="InputPhone">Phone</label>
								<input type="number" class="form-control @error('phone')is-invalid @enderror" id="InputPhone" name="phone" placeholder="Enter your phone number.." value="{{old('phone')}}">
								@error('phone')
								<div class="invalid-feedback">
									{{$message}}.
								</div>
								@enderror
							</div>
							<button type="submit" class="btn btn-primary">Submit</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
</body>
</html>