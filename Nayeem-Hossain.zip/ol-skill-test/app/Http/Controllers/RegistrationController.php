<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Registration;
use Notification;
use Validator;
use App\Notifications\registrationNotification;


class RegistrationController extends Controller
{   
	public function createUser(Request $data){
		$validateUser = $data->validate([
			'name'  => 'required|max:255',
			'email' => 'required|email|unique:registrations',
			'phone' => 'required|regex:/(01)[0-9]{9}/|size:11',
		]);
		$user = Registration::newUser($validateUser);
		$user->notify(new registrationNotification($user));
		return "Registration complete successfully!";
	}
}
