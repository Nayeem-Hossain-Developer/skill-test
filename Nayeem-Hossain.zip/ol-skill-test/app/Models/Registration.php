<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
class Registration extends Model
{
    use HasFactory,Notifiable;
    private static $user;

    protected $fillable = [
        'name', 'email', 'phone',
    ];

    public static function newUser($data)
    {
        $user = Registration::create([
        'name' => $data['name'],
        'email' => $data['email'],
        'phone' => $data['phone'],
    ]);
        return $user;
    }
}
