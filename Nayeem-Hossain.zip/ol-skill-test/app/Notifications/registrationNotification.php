<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Models\Registration;

class registrationNotification extends Notification implements ShouldQueue
{
    use Queueable;
    public $userinfo;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct(Registration $data)
    {
        
            $this->userinfo = $data;
        

    }

    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {   
    //      return (new MailMessage)->view(
    //     'registrationMail',['user' =>
    //               $this->userinfo]
    // );

        return (new MailMessage)->view('registrationMail',['user'=>$this->userinfo]);
    }

    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
