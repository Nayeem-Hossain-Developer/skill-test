<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<h3>“Dear <?php echo e($user->name); ?>, Thank you for your registration. Your registered email address is ‘<?php echo e($user->email); ?>’ and phone number ‘<?php echo e($user->phone); ?>’”</h3>
</body>
</html><?php /**PATH E:\xampp\htdocs\ol-skill-test\resources\views/registrationMail.blade.php ENDPATH**/ ?>